package pe.edu.upeu.poo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysPooApplicationTests {

	@Test
	void contextLoads() {
	}

}
