package pe.edu.upeu.syscerterlife;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysVentCrudxApplicationTests {

	@Test
	void contextLoads() {
	}

}
